﻿using System;
using System.IO;
using System.Text;
namespace Main
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Digite o nome do Jogador: ");
            string nome = Console.ReadLine();
            Jogador jogador = new Jogador(nome, 0);
            Tabuleiro tabuleiro = new Tabuleiro();
            bool gameover = true;
            while (gameover)
            {
                Tetrominos tetromino = new Tetrominos();
                string[,] pecaAtual = tetromino.GetPeca;
                if (!tabuleiro.EspacoLivreParaNovaPeca(pecaAtual))
                {
                    gameover = true;
                    break;
                }
                tabuleiro.Comecarjogo(pecaAtual);
                bool caiu = false;
                while (!caiu)
                {
                    tabuleiro.Exibircampodejogo();
                    Console.WriteLine();
                    jogador.ExibirInfo();

                    Console.WriteLine("Comandos: (a) Esquerda | (d) Direita | (s) Baixo | (r) Gira Horário | (e) Gira Anti-Horário | (q) Sair");
                    char comando = char.Parse(Console.ReadLine());
                    if (comando == 'q')
                    {
                        gameover = true;
                        break;
                    }
                    else if (comando == 'r')
                    {
                        tabuleiro.LimparPeca(pecaAtual);
                        tetromino.RotacionarHorario();
                        pecaAtual = tetromino.GetPeca;
                        tabuleiro.InserirPeca(pecaAtual);
                        tabuleiro.LimparPeca(pecaAtual);
                        if (tabuleiro.PodeDescer(pecaAtual))
                        {
                            tabuleiro.Movimentar('s', pecaAtual);
                            tabuleiro.InserirPeca(pecaAtual);
                        }
                        else
                        {
                            tabuleiro.InserirPeca(pecaAtual);
                            tabuleiro.FixarPeca(pecaAtual);
                            caiu = true;
                        }
                    }
                    else if (comando == 'e')
                    {
                        tabuleiro.LimparPeca(pecaAtual);
                        tetromino.RotacionarAntiHorario();
                        pecaAtual = tetromino.GetPeca;
                        tabuleiro.InserirPeca(pecaAtual);
                        tabuleiro.LimparPeca(pecaAtual);
                        if (tabuleiro.PodeDescer(pecaAtual))
                        {
                            tabuleiro.Movimentar('s', pecaAtual);
                            tabuleiro.InserirPeca(pecaAtual);
                        }
                        else
                        {
                            tabuleiro.InserirPeca(pecaAtual);
                            tabuleiro.FixarPeca(pecaAtual);
                            caiu = true;
                        }
                    }
                    else if (comando == 'a' || comando == 'd')
                    {
                        tabuleiro.LimparPeca(pecaAtual);
                        tabuleiro.Movimentar(comando, pecaAtual);
                        tabuleiro.InserirPeca(pecaAtual);
                        tabuleiro.LimparPeca(pecaAtual);
                        if (tabuleiro.PodeDescer(pecaAtual))
                        {
                            tabuleiro.Movimentar('s', pecaAtual);
                            tabuleiro.InserirPeca(pecaAtual);
                        }
                        else
                        {
                            tabuleiro.InserirPeca(pecaAtual);
                            tabuleiro.FixarPeca(pecaAtual);
                            caiu = true;
                        }
                    }
                    else if (comando == 's')
                    {
                        tabuleiro.LimparPeca(pecaAtual);
                        if (tabuleiro.PodeDescer(pecaAtual))
                        {
                            tabuleiro.Movimentar('s', pecaAtual);
                            tabuleiro.InserirPeca(pecaAtual);
                        }
                        else
                        {
                            tabuleiro.InserirPeca(pecaAtual);
                            tabuleiro.FixarPeca(pecaAtual);
                            caiu = true;
                        }
                    }
                }

                int linhasRemovidas = tabuleiro.RemoverLinhasCompletas();
                if (linhasRemovidas > 0)
                    jogador.AtualizarPontuacao(300 + (linhasRemovidas - 1) * 100, jogador);
            }

            tabuleiro.Exibircampodejogo();
            Console.WriteLine();
            jogador.ExibirInfo();
            Console.WriteLine("\nGAME OVER! Pontuação final de " + jogador.Nome + ": " + jogador.Pontuacao);
            Console.WriteLine("Pressione ENTER para sair...");
            Console.ReadLine();
            try
            {
                StreamWriter arq = new StreamWriter("scores.txt", true, Encoding.UTF8);
                arq.Write($"Jogador:{jogador.Nome}\nPontuacao:{jogador.Pontuacao}");
                arq.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.Message);
            }
            Console.ReadLine();
        }
    }
}